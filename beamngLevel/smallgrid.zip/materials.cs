singleton Material(GroundGrid)
{
    internalName = "Grid";
    diffuseSize = "1";
    detailDistance = "2000";
    detailSize = "1";
    useAnisotropic[0] = "1";
   mapTo = "grid_10_diff";
   colorMap[0] = "levels/smallgrid/grid_10_diff";
   detailScale[0] = "50 50";
   materialTag0 = "Miscellaneous";
};
